make clean
make
java ComputeClosestPair
